'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const test = require('node:test');

const {
  FORMAL_ASSET_TYPES,
  QuestionSyncError,
  QuestionSyncStore,
  buildQuestionListBody,
  buildScope,
  catalogTreeUrl,
  classifyQuestionResponse,
  createRequestGate,
  downloadAsset,
  finalizeQuestion,
  normalizeAssetType,
  normalizeCatalogTree,
  parseQuestionListPayload,
  parseQuestionListTotalPayload,
  parseDifficulty,
  parseArgs,
  postQuestionList,
  retryDelay,
  runSync,
  selectCatalogs,
  serializeFormBody,
  validatePageResult,
  listWindow,
  catalogLastPage,
  catalogSafetyPageLimit,
  growTargetPages,
  isCookieSwitchError,
  isPageLevelError,
  DEFAULT_LIST_CONCURRENCY,
  DEFAULT_PAGINATION_SAFETY_LIMIT,
  PAGE_RESULT,
  SITE_PAGE_LIMIT,
  VerificationRequiredError,
} = require('../zujuan_question_sync.cjs');
const { readLiveRunProgress } = require('../lib/api_store.cjs');

const LIST_HTML = `
<div class="tk-quest-item quesroot new" questionid="35020603" bankid="2">
  <div class="ques-additional">
    <div class="top-msg"><a class="ques-src" href="/2p3410930.html" title="原始出处：第二十五章 一元二次方程">26-27九年级上·全国·课后作业</a></div>
    <div class="info-cnt">解答题-问答题</div><div class="info-cnt">适中 (0.55)</div>
    <div class="knowledge-list"><a class="knowledge-item" href="/czsx/zsd223709/">化成一元二次方程的一般式</a><a class="knowledge-item" href="/czsx/zsd223709/tre5-15091">问题解决能力</a></div>
    <div class="right-msg"><span class="tag">名校</span></div>
  </div>
  <div class="exam-item__cnt">1 . 计算<img src="https://staticzujuan.xkw.com/quesimg/Upload/formula/a.png"><br>(1)求值</div>
  <div class="exam-item__info"><span class="no-bound" title="2026/08/16">2026/08/16</span><span title="470次组卷">470次组卷</span><span class="look-more-src"><span class="info-txt">2卷引用：试卷甲</span><div class="more-src-links"><a class="src-item" href="/2p1.html" title="试卷甲">试卷甲</a><a class="src-item" href="/2p2.html">试卷乙</a></div></span></div>
  <div class="ctrl-box"><a class="detail" href="/2q35020603.html">详情</a><a class="addques" quesid="35020603" qyid="1103" qyname="解答题" qdid="3" qdname="适中" qdvalue="0.55" categoryId="4690" categoryName="代数式" titleabbreviation="26-27九上—全国—作业">加入</a></div>
</div>`;

function tempDb() {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'zujuan-question-sync-'));
  return { directory, dbPath: path.join(directory, 'collector.sqlite3') };
}

function listHtml(questionId) {
  return LIST_HTML.replaceAll('35020603', String(questionId));
}

function listApiText(total, questionIds) {
  const html = (Array.isArray(questionIds) ? questionIds : []).map((id) => listHtml(id)).join('');
  return JSON.stringify({ code: '0', data: { total, html } });
}

function mockSyncPage(handler) {
  return {
    goto: async () => ({ status: 200 }),
    url: () => 'https://zujuan.xkw.com/czsx/zj261285/',
    isClosed: () => false,
    evaluate: async (_fn, args) => {
      if (!args || typeof args !== 'object' || !args.body) {
        return { challenge: false, text: '', title: '' };
      }
      const params = new URLSearchParams(args.body);
      return handler({
        curPage: Number(params.get('curPage')),
        categoryId: String(params.get('categoryId') || ''),
        params,
      });
    },
    close: async () => {},
  };
}

function baseSyncOptions(directory, dbPath, extra = {}) {
  return {
    baseUrl: 'https://zujuan.xkw.com',
    treeBaseUrl: 'https://static.zxxk.com',
    apiPath: '/zujuan-api/question/list',
    bankId: 2,
    bankPath: 'czsx',
    textbookId: '260617',
    catalogIds: [],
    catalogLevels: [],
    maxCatalogs: 0,
    startPage: 1,
    maxPages: 1000,
    maxPagesProvided: false,
    limit: 0,
    headless: false,
    cdpUrl: null,
    delayMin: 0,
    delayMax: 0,
    timeout: 1000,
    verificationTimeout: 1000,
    verificationPoll: 0,
    verificationProbeInterval: 1,
    downloadAssets: false,
    saveRaw: false,
    resume: false,
    concurrency: 8,
    fallbackProfileDirs: [],
    dbPath,
    dataDir: directory,
    profileDir: directory,
    sleepFn: async () => {},
    randomFn: () => 0,
    ...extra,
  };
}

const SAMPLE_TREE = {
  id: '260617',
  title: '九年级上册',
  children: [{ id: '261285', title: '第一章', children: [] }],
};

test('目录归一化使用嵌套 display parent，并正确生成知识点接口参数', () => {
  const tree = normalizeCatalogTree({
    bankId: 2,
    id: '260617',
    parentId: '195847',
    title: '九年级上册',
    children: [{
      id: '261285', title: '第一章', isKnowledge: 0, parentId: '260617', children: [{
        id: '261286', title: '第一节', isKnowledge: 0, parentId: '261285', children: [{
          id: '5597', title: '知识点', isKnowledge: 1, parentId: '9999', href: '/czsx/zj261286/ctk5597', children: [],
        }],
      }],
    }],
  });
  assert.equal(tree.nodes.length, 3);
  assert.equal(tree.nodes[2].parentExternalId, '261286');
  assert.equal(tree.nodes[2].rawParentExternalId, '9999');
  assert.deepEqual(tree.nodes[2].ancestorIds, ['261285', '261286', '5597']);
  assert.equal(tree.nodes[2].categoryId, '261286');
  assert.equal(tree.nodes[2].catelogTokpointId, '5597');
  assert.equal(tree.nodes[0].categoryId, '261285');
  assert.equal(tree.root.externalId, '260617');
  assert.equal(tree.nodes[0].sortOrder, 0);
});

test('静态目录 URL、初中数学默认值和 API POST body 契约', () => {
  const options = { bankId: 2, textbookId: '260617', bankPath: 'czsx', baseUrl: 'https://zujuan.xkw.com' };
  const url = catalogTreeUrl({ ...options, timestamp: 123 });
  assert.equal(url, 'https://static.zxxk.com/zujuan/tree/ct_2_260617.json?v=123&withCredentials=false');
  const body = buildQuestionListBody(options, {
    externalId: '5597', categoryId: '261286', catelogTokpointId: '5597',
  }, 7);
  assert.equal(body.curPage, '7');
  assert.equal(body.categoryId, '261286');
  assert.equal(body.catelogTokpointId, '5597');
  assert.equal(body['categoryIds[0]'], '0');
  assert.equal(body.canTreeMultiple, 'false');
  assert.equal(body.credentials, undefined);
  const encoded = serializeFormBody(body);
  assert.match(encoded, /pageName=zj/);
  assert.match(encoded, /categoryIds%5B0%5D=0/);
});

test('浏览器 page.evaluate 实际收到 form-urlencoded 字符串而不是 body 对象', async () => {
  let evaluateArgs = null;
  const page = {
    evaluate: async (_fetchFn, args) => {
      evaluateArgs = args;
      return { status: 200, headers: {}, text: '{"code":"0","data":{"total":0,"html":""}}' };
    },
  };
  await postQuestionList(page, {
    baseUrl: 'https://zujuan.xkw.com',
    bankId: 2,
    delayMin: 0,
    delayMax: 0,
  }, { externalId: '261285', categoryId: '261285', catelogTokpointId: '0' }, 1);
  assert.equal(typeof evaluateArgs.body, 'string');
  assert.match(evaluateArgs.body, /categoryIds%5B0%5D=0/);
  assert.equal(evaluateArgs.credentials, 'include');
  assert.equal(evaluateArgs.headers['X-Requested-With'], 'XMLHttpRequest');
});

test('题型、页面三档难度、原始 qdid、来源分类和使用统计完整保留', () => {
  const parsed = parseQuestionListPayload({
    code: '0', data: { total: 1, html: LIST_HTML },
  });
  const question = parsed.questions[0];
  assert.equal(question.externalId, '35020603');
  assert.equal(question.questionType, '解答题-问答题');
  assert.equal(question.questionTypeId, '1103');
  assert.equal(question.questionTypeName, '解答题');
  assert.equal(question.difficultyLabel, '适中');
  assert.equal(question.difficultyCode, '3');
  assert.equal(question.rawDifficulty.qdid, '3');
  assert.equal(question.easeCoefficient, 0.55);
  assert.equal(question.sourceShort, '26-27九年级上·全国·课后作业');
  assert.equal(question.sourceTitle, '第二十五章 一元二次方程');
  assert.equal(question.sourceUrl, 'https://zujuan.xkw.com/2p3410930.html');
  assert.equal(question.detailUrl, 'https://zujuan.xkw.com/2q35020603.html');
  assert.equal(question.titleAbbreviation, '26-27九上—全国—作业');
  assert.equal(question.providerCategoryId, '4690');
  assert.equal(question.providerCategoryName, '代数式');
  assert.equal(question.websiteTimeText, '2026/08/16');
  assert.equal(question.useCount, 470);
  assert.equal(question.referenceCount, 2);
  assert.equal(question.referencePapers.length, 2);
  assert.equal(question.isNew, true);
  assert.equal(question.answerStatus, 'not_collected');
  assert.equal(question.detailFetched, false);
});

test('知识点、能力点、provider tags 和素材使用独立维度及规范类型', () => {
  const question = parseQuestionListPayload({ code: '0', data: { total: 1, html: LIST_HTML } }).questions[0];
  assert.deepEqual(question.knowledge.map((entry) => [entry.kind, entry.externalId]), [
    ['knowledge_point', '223709'], ['ability', '15091'],
  ]);
  assert.deepEqual(question.providerLabels.map((entry) => entry.value), ['名校', '新题']);
  assert.equal(question.assets[0].type, 'formula_image');
  assert.ok(FORMAL_ASSET_TYPES.includes(question.assets[0].assetType));
  assert.equal(normalizeAssetType('https://x/thing.svg'), 'svg');
  assert.equal(normalizeAssetType('https://x/thing.bin'), 'other');
});

test('分页校验允许空页和跨页部分重复，但拒绝完全相同的非空页', () => {
  const page = {
    total: 10012,
    questions: Array.from({ length: 10 }, (_, index) => ({ externalId: String(index + 1) })),
    questionIds: Array.from({ length: 10 }, (_, index) => String(index + 1)),
  };
  const signature = validatePageResult(page, 1, 1002, new Set());
  assert.equal(typeof signature, 'string');
  assert.equal(validatePageResult({ total: 10013, questions: [], questionIds: [] }, 2, 1002, new Set()), null);
  const overlapping = {
    total: 10013,
    questions: [{ externalId: '9' }, { externalId: '11' }],
    questionIds: ['9', '11'],
  };
  assert.equal(typeof validatePageResult(overlapping, 2, 1002, new Set([signature]), new Set(page.questionIds), 10012), 'string');
  assert.throws(() => validatePageResult(page, 2, 1002, new Set([signature])), /重复/);
  assert.throws(() => validatePageResult({ total: 1, questions: [{ externalId: '1' }, { externalId: '1' }], questionIds: ['1', '1'] }, 1, 1, new Set()), /重复/);
});

test('HTTP 重试/验证分类及退避策略', () => {
  assert.equal(isPageLevelError({ code: 'http_500' }), true);
  assert.equal(isPageLevelError({ code: 'waiting_verification' }), false);
  assert.equal(classifyQuestionResponse({ status: 503, text: 'busy' }).kind, 'retry');
  assert.equal(classifyQuestionResponse({ status: 429, text: 'slow' }).throttled, true);
  assert.equal(classifyQuestionResponse({ status: 403, text: 'forbidden' }).kind, 'verification');
  assert.equal(classifyQuestionResponse({ status: 200, text: '<html>验证码</html>' }).kind, 'verification');
  assert.equal(retryDelay('normal', 0, {}, () => 0), 2000);
  assert.equal(retryDelay('normal', 2, {}, () => 0), 12000);
  assert.equal(retryDelay('429', 0, { 'retry-after': '7' }, () => 0), 7000);
});

test('素材 HTTP 失败 fail closed，并按 2/5/12 秒重试后抛错', async () => {
  const waits = [];
  let calls = 0;
  const context = {
    request: {
      get: async () => {
        calls += 1;
        return { status: 503, headers: {}, body: async () => Buffer.from('busy') };
      },
    },
  };
  await assert.rejects(
    downloadAsset(context, {
      timeout: 1000,
      dataDir: os.tmpdir(),
      sleepFn: async (ms) => waits.push(ms),
      randomFn: () => 0,
    }, { sourceUrl: 'https://staticzujuan.xkw.com/quesimg/a.png', type: 'question_image' }),
    /HTTP 503/,
  );
  assert.equal(calls, 4);
  assert.deepEqual(waits, [2000, 5000, 12000]);
});

test('resume scope 区分素材模式，但允许放宽验收边界继续克隆断点', () => {
  const { directory, dbPath } = tempDb();
  const store = new QuestionSyncStore(dbPath, { dataDir: directory });
  try {
    const noAssets = store.beginRun({
      textbookId: '260617', bankId: 2, bankPath: 'czsx', downloadAssets: false,
      maxCatalogs: 1, maxPages: 1, limit: 5,
    });
    store.finishRun(noAssets, 'interrupted', {});
    const withAssets = store.beginRun({
      textbookId: '260617', bankId: 2, bankPath: 'czsx', downloadAssets: true,
      maxCatalogs: 100, maxPages: 1000, limit: 0,
    });
    assert.notEqual(withAssets, noAssets);
    assert.equal(store.lastBeginMeta.clonedFrom, null);

    const widerProbe = store.beginRun({
      textbookId: '260617', bankId: 2, bankPath: 'czsx', downloadAssets: false,
      maxCatalogs: 100, maxPages: 1000, limit: 0,
    });
    assert.notEqual(widerProbe, noAssets);
    assert.equal(store.lastBeginMeta.clonedFrom, noAssets);
  } finally {
    store.close();
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('全新 SQLite 自包含错误与原始列表快照表，且均可实际写入', () => {
  const { directory, dbPath } = tempDb();
  const store = new QuestionSyncStore(dbPath, { dataDir: directory });
  try {
    const runId = store.beginRun({ textbookId: '260617', bankId: 2, bankPath: 'czsx' });
    const nodes = [{
      externalId: '261285', name: '第一章', level: 1, type: 'chapter',
      ancestorIds: ['261285'], categoryId: '261285', catelogTokpointId: '0',
    }];
    const question = parseQuestionListPayload({ code: '0', data: { total: 1, html: LIST_HTML } }).questions[0];
    store.savePage({
      runId,
      textbookExternalId: '260617',
      catalog: { ...nodes[0], chapterExternalId: '261285' },
      nodes,
      pageNumber: 1,
      expectedTotal: 1,
      expectedPages: 1,
      questions: [question],
      queryFingerprint: 'fresh-db-raw',
      rawSnapshot: {
        sourceUrl: 'https://zujuan.xkw.com/zujuan-api/question/list',
        contentHash: 'b'.repeat(64),
        filePath: path.join(directory, 'raw', 'page.json.gz'),
      },
    });
    store.recordError(
      runId,
      'test',
      new QuestionSyncError('原始错误', 'original_failure'),
      'https://zujuan.xkw.com/zujuan-api/question/list',
    );
    assert.equal(store.db.prepare(
      "SELECT COUNT(*) AS n FROM sqlite_master WHERE type = 'table' AND name IN ('source_snapshots', 'sync_errors')",
    ).get().n, 2);
    assert.equal(store.db.prepare('SELECT COUNT(*) AS n FROM source_snapshots WHERE run_id = ?').get(runId).n, 1);
    assert.equal(store.db.prepare('SELECT COUNT(*) AS n FROM sync_errors WHERE run_id = ?').get(runId).n, 1);
    const foreignKeys = store.db.prepare('PRAGMA foreign_key_list(source_snapshots)').all();
    assert.ok(foreignKeys.some((row) => row.table === 'sync_runs' && row.from === 'run_id'));
  } finally {
    store.close();
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('SQLite 重放按 provider/question 去重，目录关系、素材、checkpoint 同事务保存', () => {
  const { directory, dbPath } = tempDb();
  const store = new QuestionSyncStore(dbPath, { dataDir: directory });
  try {
    const runId = store.beginRun({ textbookId: '260617', bankId: 2, bankPath: 'czsx' });
    const nodes = [
      { externalId: '261285', name: '第一章', level: 1, type: 'chapter', ancestorIds: ['261285'], categoryId: '261285', catelogTokpointId: '0' },
      { externalId: '261286', parentExternalId: '261285', name: '第一节', level: 2, type: 'section', ancestorIds: ['261285', '261286'], categoryId: '261286', catelogTokpointId: '0' },
      { externalId: '5597', parentExternalId: '261286', name: '知识点', level: 3, type: 'point', isKnowledge: true, ancestorIds: ['261285', '261286', '5597'], categoryId: '261286', catelogTokpointId: '5597' },
    ];
    const question = parseQuestionListPayload({ code: '0', data: { total: 1, html: LIST_HTML } }).questions[0];
    question.assets[0] = { ...question.assets[0], storagePath: 'assets/aa/formula.png', contentSha256: 'a'.repeat(64) };
    store.saveCatalogTree(runId, '260617', nodes);
    const catalog = { ...nodes[2], chapterExternalId: '261285' };
    store.savePage({ runId, textbookExternalId: '260617', catalog, nodes, pageNumber: 1, expectedTotal: 1, expectedPages: 1, questions: [question], queryFingerprint: 'scope-1' });
    store.savePage({ runId, textbookExternalId: '260617', catalog, nodes, pageNumber: 1, expectedTotal: 1, expectedPages: 1, questions: [question], queryFingerprint: 'scope-1' });
    assert.equal(store.db.prepare('SELECT COUNT(*) AS n FROM questions').get().n, 1);
    assert.equal(store.db.prepare('SELECT COUNT(*) AS n FROM sync_run_question_items').get().n, 1);
    assert.equal(store.db.prepare('SELECT COUNT(*) AS n FROM sync_run_question_catalogs').get().n, 3);
    assert.equal(store.db.prepare('SELECT COUNT(*) AS n FROM sync_run_question_assets').get().n, 1);
    assert.equal(store.getRunCheckpoint(runId, 'scope-1'), 1);
    const row = store.db.prepare('SELECT detail_fetched, content_source, content_complete, answer_status FROM sync_run_question_items').get();
    assert.deepEqual({ ...row }, { detail_fetched: 0, content_source: 'list_api', content_complete: 1, answer_status: 'not_collected' });
    assert.equal(store.db.prepare('SELECT COUNT(*) AS n FROM sync_run_question_tags WHERE dimension = \'provider_category\'').get().n, 1);
    assert.equal(store.db.prepare('SELECT COUNT(*) AS n FROM sync_run_question_tags WHERE dimension = \'category\'').get().n, 0);
  } finally {
    store.close();
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('默认有头、固定 profile，完整抓取才允许 success', () => {
  const script = require('../zujuan_question_sync.cjs');
  const options = script.parseArgs([]);
  assert.equal(options.headless, false);
  assert.match(options.profileDir, /zujuan-sync-profile$/);
  assert.equal(script.parseArgs(['--cdp-url', 'http://127.0.0.1:9222']).cdpUrl, 'http://127.0.0.1:9222');
  assert.equal(options.delayMin, 2500);
  assert.equal(options.delayMax, 4000);
  assert.equal(options.concurrency, 8);
  assert.equal(DEFAULT_LIST_CONCURRENCY, 8);
  assert.deepEqual(listWindow(1, Infinity, 8), [1, 2, 3, 4, 5, 6, 7, 8]);
  assert.deepEqual(listWindow(1002, 1005, 8), [1002, 1003, 1004, 1005]);
  assert.equal(catalogLastPage({ maxPagesProvided: false, maxPages: 1000 }), DEFAULT_PAGINATION_SAFETY_LIMIT);
  assert.equal(catalogLastPage({ maxPagesProvided: false }), DEFAULT_PAGINATION_SAFETY_LIMIT);
  assert.equal(catalogLastPage({ maxPagesProvided: true, maxPages: 3 }), 3);
  assert.equal(catalogLastPage({ maxPages: 5000 }), DEFAULT_PAGINATION_SAFETY_LIMIT);
  assert.equal(catalogLastPage({ maxPagesProvided: true, maxPages: 5000 }), 5000);
  assert.equal(catalogSafetyPageLimit({}), DEFAULT_PAGINATION_SAFETY_LIMIT);
  assert.equal(growTargetPages(0, 10020, 10), 1002);
  assert.equal(growTargetPages(1002, 10000, 10), 1002);
  assert.equal(SITE_PAGE_LIMIT, 1000);
  assert.equal(script.parseArgs(['--concurrency', '8']).concurrency, 8);
  assert.equal(script.parseDifficulty('较易 (0.85)').label, '较易');
  const emptyPage = script.parseQuestionListPayload({ code: '0', data: { total: 1, html: '' } });
  assert.deepEqual(emptyPage.questionIds, []);
  assert.equal(emptyPage.total, 1);
  assert.throws(() => script.parseQuestionListPayload({ code: '1', data: { total: 1, html: '' } }), QuestionSyncError);
  assert.throws(() => script.parseQuestionListPayload('not-json'), QuestionSyncError);
});

test('HTTP Collector 兼容参数映射为固定教材范围，并支持指定 run 续采', () => {
  const options = parseArgs([
    '--acknowledge-source-policy',
    '--textbook-id', '260617',
    '--chapter-id', '261314',
    '--max-pages', '3',
    '--resume-run-id', '19',
  ]);
  assert.equal(options.chapterId, '261314');
  assert.equal(options.resumeRunId, 19);
  assert.deepEqual(buildScope(options).chapterIds, ['261314']);
  assert.deepEqual(buildScope(options).catalogLevels, [1, 2, 3]);
  assert.equal(buildScope(options).detailFallback, true);
  assert.equal(buildScope(options).requireAssets, true);
  assert.throws(
    () => parseArgs(['--resume-run-id', '19', '--no-resume']),
    /不能与 --no-resume 同时使用/,
  );
});

test('CDP 连接共享 context 但新建专用 tab，结束不关闭用户 browser/context', async () => {
  const { directory, dbPath } = tempDb();
  const userPage = {
    url: () => 'https://zujuan.xkw.com/czsx/zj260617/',
    close: async () => { throw new Error('user tab must not close'); },
  };
  let ownPageClosed = false;
  const page = {
    goto: async () => ({ status: 200 }),
    evaluate: async (_fn, args) => {
      if (!args || typeof args !== 'object' || !args.body) {
        return { challenge: false, text: '', title: '' };
      }
      const curPage = Number(new URLSearchParams(args.body).get('curPage'));
      const categoryId = String(new URLSearchParams(args.body).get('categoryId') || '');
      if (categoryId === '261285' && curPage > 1) {
        return { status: 200, headers: {}, text: listApiText(1, []) };
      }
      return { status: 200, headers: {}, text: JSON.stringify({
        code: '0', data: { total: 1, html: LIST_HTML },
      }) };
    },
    close: async () => { ownPageClosed = true; },
  };
  let contextClosed = false;
  let browserClosed = false;
  const context = {
    pages: () => [userPage],
    newPage: async () => page,
    close: async () => { contextClosed = true; },
  };
  const browser = {
    contexts: () => [context],
    close: async () => { browserClosed = true; },
  };
  try {
    const result = await runSync({
      baseUrl: 'https://zujuan.xkw.com', treeBaseUrl: 'https://static.zxxk.com',
      apiPath: '/zujuan-api/question/list', bankId: 2, bankPath: 'czsx', textbookId: '260617',
      catalogIds: [], catalogLevels: [], maxCatalogs: 0, startPage: 1, maxPages: 1000,
      maxPagesProvided: false, limit: 0, headless: false, cdpUrl: 'http://127.0.0.1:9222',
      delayMin: 0, delayMax: 0, timeout: 1000, verificationTimeout: 1000,
      verificationPoll: 0, verificationProbeInterval: 1, downloadAssets: false,
      saveRaw: false, resume: false, dbPath, dataDir: directory, profileDir: directory,
      sleepFn: async () => {}, randomFn: () => 0,
    }, {
      playwright: { chromium: { connectOverCDP: async () => browser } },
      catalogTree: { id: '260617', title: '九年级上册', children: [{ id: '261285', title: '第一章', children: [] }] },
    });
    assert.equal(result.status, 'success');
    assert.equal(ownPageClosed, true);
    assert.equal(contextClosed, false);
    assert.equal(browserClosed, false);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('CLI CDP 收尾在不关闭远端 browser 的情况下退出 transport 句柄', () => {
  const { directory, dbPath } = tempDb();
  const scriptPath = path.resolve(__dirname, '..', 'zujuan_question_sync.cjs');
  const childCode = `
    const Module = require('node:module');
    const originalLoad = Module._load;
    const tree = { id: '260617', title: '九年级上册', children: [{ id: '261285', title: '第一章', children: [] }] };
    const page = {
      goto: async () => ({ status: 200 }),
      evaluate: async (_fn, arg) => {
        if (typeof arg === 'string') return tree;
        if (arg && typeof arg === 'object' && arg.body) {
          return { status: 200, headers: {}, text: JSON.stringify({ code: '0', data: { total: 0, html: '' } }) };
        }
        return { challenge: false, text: '', title: '' };
      },
      close: async () => {},
    };
    const context = { pages: () => [], newPage: async () => page };
    const browser = { contexts: () => [context] };
    const fakePlaywright = { chromium: { connectOverCDP: async () => browser } };
    Module._load = function(request, parent, isMain) {
      if (request === 'playwright-core') return fakePlaywright;
      return originalLoad.call(this, request, parent, isMain);
    };
    process.argv = [process.execPath, ${JSON.stringify(scriptPath)},
      '--cdp-url', 'http://127.0.0.1:9222', '--db', ${JSON.stringify(dbPath)},
      '--data-dir', ${JSON.stringify(directory)}, '--profile-dir', ${JSON.stringify(directory)},
      '--max-catalogs', '1', '--max-pages', '1', '--delay-min', '0', '--delay-max', '0',
      '--verification-timeout', '100', '--verification-probe-interval', '1',
      '--no-download-assets', '--no-save-raw'];
    setInterval(() => {}, 60000);
    require(${JSON.stringify(scriptPath)}).runCli();
  `;
  try {
    const child = spawnSync(process.execPath, ['-e', childCode], {
      encoding: 'utf8',
      timeout: 3000,
    });
    assert.equal(child.error, undefined, child.error?.stack || child.stderr);
    assert.equal(child.status, 0, child.stderr);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('--limit 只在完整 API 页落库后停止，不推进半页 checkpoint', async () => {
  const { directory, dbPath } = tempDb();
  const firstPageHtml = Array.from({ length: 10 }, (_, index) => (
    LIST_HTML.replaceAll('35020603', String(70000000 + index))
  )).join('');
  const apiPages = [];
  const page = {
    goto: async () => ({ status: 200 }),
    evaluate: async (_fetchFn, args) => {
      if (args?.body) apiPages.push(Number(new URLSearchParams(args.body).get('curPage')));
      return { status: 200, headers: {}, text: JSON.stringify({
        code: '0', data: { total: 11, html: firstPageHtml },
      }) };
    },
  };
  const options = {
    baseUrl: 'https://zujuan.xkw.com', treeBaseUrl: 'https://static.zxxk.com',
    apiPath: '/zujuan-api/question/list', bankId: 2, bankPath: 'czsx', textbookId: '260617',
    catalogIds: [], catalogLevels: [], maxCatalogs: 0, startPage: 1, maxPages: 1000,
    maxPagesProvided: false, limit: 5, headless: false, cdpUrl: null,
    delayMin: 0, delayMax: 0, timeout: 1000, verificationTimeout: 1000,
    verificationPoll: 0, verificationProbeInterval: 1, downloadAssets: false,
    saveRaw: false, resume: false, dbPath, dataDir: directory, profileDir: directory,
    sleepFn: async () => {}, randomFn: () => 0,
  };
  try {
    const result = await runSync(options, {
      context: {},
      page,
      catalogTree: { id: '260617', title: '九年级上册', children: [{ id: '261285', title: '第一章', children: [] }] },
    });
    assert.equal(result.status, 'interrupted');
    assert.equal(result.counters.questionsSeen, 10);
    assert.deepEqual(apiPages, [1]);
    const replay = new QuestionSyncStore(dbPath, { dataDir: directory });
    try {
      const row = replay.db.prepare('SELECT page_number, question_count FROM sync_run_catalog_pages').get();
      assert.deepEqual({ ...row }, { page_number: 1, question_count: 10 });
      const checkpoint = replay.db.prepare('SELECT last_completed_page FROM sync_run_checkpoints WHERE run_id = ?').get(result.runId);
      assert.equal(checkpoint.last_completed_page, 1);
    } finally {
      replay.close();
    }
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('request gate 串行安排页面请求间隔', async () => {
  let now = 1000;
  const originalNow = Date.now;
  const waits = [];
  Date.now = () => now;
  try {
    const gate = createRequestGate(10, 10);
    const wait = async (ms) => { waits.push(ms); now += ms; };
    await gate(wait);
    await gate(wait);
    assert.deepEqual(waits, [10]);
  } finally {
    Date.now = originalNow;
  }
});

test('total 从 10012 变为 10013 后继续抓取，空页结束目录', async () => {
  const { directory, dbPath } = tempDb();
  const catalogPages = [];
  const totals = [];
  const page = mockSyncPage(({ curPage, categoryId }) => {
    if (categoryId !== '261285') {
      return { status: 200, headers: {}, text: listApiText(10012, ['35020603']) };
    }
    catalogPages.push(curPage);
    if (curPage === 1) {
      totals.push(10012);
      return { status: 200, headers: {}, text: listApiText(10012, ['80000001']) };
    }
    if (curPage === 2) {
      totals.push(10013);
      return { status: 200, headers: {}, text: listApiText(10013, ['80000002']) };
    }
    return { status: 200, headers: {}, text: listApiText(10013, []) };
  });
  try {
    const result = await runSync(baseSyncOptions(directory, dbPath), {
      context: {},
      page,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(result.status, 'success');
    assert.deepEqual([...new Set(catalogPages)].sort((a, b) => a - b), [1, 2, 3, 4, 5, 6, 7, 8]);
    assert.deepEqual([...totals].sort((a, b) => a - b), [10012, 10013]);
    assert.equal(result.completeness.scanComplete, true);
    assert.equal(result.completeness.complete, true);
    assert.equal(result.completeness.counts.questionCount, 2);
    const replay = new QuestionSyncStore(dbPath, { dataDir: directory });
    try {
      const progress = replay.getRunCatalogProgress(result.runId, '260617', '261285');
      assert.equal(progress.status, 'completed');
      assert.equal(progress.expectedTotal, 10013);
      assert.equal(progress.lastCompletedPage, 2);
      assert.equal(replay.db.prepare(
        "SELECT COUNT(*) AS n FROM sync_run_catalog_pages WHERE COALESCE(result_type, 'success') = 'success'",
      ).get().n, 2);
    } finally {
      replay.close();
    }
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('到达 expectedPages 后仍有题目时继续抓取', async () => {
  const { directory, dbPath } = tempDb();
  const catalogPages = [];
  const page = mockSyncPage(({ curPage, categoryId }) => {
    if (categoryId !== '261285') {
      return { status: 200, headers: {}, text: listApiText(10, ['35020603']) };
    }
    catalogPages.push(curPage);
    if (curPage === 1) return { status: 200, headers: {}, text: listApiText(10, ['80000011']) };
    if (curPage === 2) return { status: 200, headers: {}, text: listApiText(10, ['80000012']) };
    return { status: 200, headers: {}, text: listApiText(10, []) };
  });
  try {
    const result = await runSync(baseSyncOptions(directory, dbPath), {
      context: {},
      page,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(result.status, 'success');
    assert.deepEqual([...new Set(catalogPages)].sort((a, b) => a - b), [1, 2, 3, 4, 5, 6, 7, 8]);
    assert.equal(result.completeness.counts.questionCount, 2);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('跨页部分题号重复时按唯一题号统计且不失败', async () => {
  const { directory, dbPath } = tempDb();
  const page = mockSyncPage(({ curPage, categoryId }) => {
    if (categoryId !== '261285') {
      return { status: 200, headers: {}, text: listApiText(100, ['35020603']) };
    }
    if (curPage === 1) return { status: 200, headers: {}, text: listApiText(100, ['90000001', '90000002']) };
    if (curPage === 2) return { status: 200, headers: {}, text: listApiText(100, ['90000002', '90000003']) };
    return { status: 200, headers: {}, text: listApiText(100, []) };
  });
  try {
    const result = await runSync(baseSyncOptions(directory, dbPath), {
      context: {},
      page,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(result.status, 'success');
    assert.equal(result.counters.questionsSeen, 4);
    assert.equal(result.completeness.counts.questionCount, 3);
    const live = readLiveRunProgress(dbPath, result.runId, { textbookExternalId: '260617' });
    assert.equal(live.available, true);
    assert.equal(live.collectedQuestionCount, 3);
    assert.equal(live.uniqueQuestionCount, 3);
    assert.equal(live.scanComplete, true);
    assert.equal(live.progressPercent, 100);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('完全相同的非空页重复时记录异常并结束扫描，不中断整本任务', async () => {
  const { directory, dbPath } = tempDb();
  const page = mockSyncPage(({ curPage, categoryId }) => {
    if (categoryId !== '261285') {
      return { status: 200, headers: {}, text: listApiText(20, ['35020603']) };
    }
    return { status: 200, headers: {}, text: listApiText(20, ['91000001']) };
  });
  try {
    const result = await runSync(baseSyncOptions(directory, dbPath), {
      context: {},
      page,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(result.status, 'success');
    assert.equal(result.completeness.scanComplete, true);
    assert.equal(result.completeness.dataComplete, false);
    assert.equal(result.completeness.snapshotComplete, false);
    assert.equal(result.completeness.completionQuality, 'completed_with_issues');
    const replay = new QuestionSyncStore(dbPath, { dataDir: directory });
    try {
      const progress = replay.getRunCatalogProgress(result.runId, '260617', '261285');
      assert.equal(progress.scanComplete, true);
      assert.equal(progress.dataComplete, false);
      assert.ok(progress.duplicatePageCount > 0);
    } finally {
      replay.close();
    }
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('未遇到空页就达到 --max-pages 或 --limit 时任务仍不完整', async () => {
  const { directory, dbPath } = tempDb();
  const maxPage = mockSyncPage(({ categoryId }) => ({
    status: 200,
    headers: {},
    text: categoryId === '261285'
      ? listApiText(10012, ['92000001'])
      : listApiText(10012, ['35020603']),
  }));
  try {
    const maxPagesResult = await runSync(baseSyncOptions(directory, dbPath, {
      maxPages: 1,
      maxPagesProvided: true,
    }), {
      context: {},
      page: maxPage,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(maxPagesResult.status, 'interrupted');
    assert.equal(maxPagesResult.completeness.complete, false);
    assert.equal(maxPagesResult.completeness.scanComplete, false);
    assert.ok(maxPagesResult.completeness.reasons.some((reason) => /扫描完成|limit/.test(reason)));
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }

  const { directory: limitDir, dbPath: limitDb } = tempDb();
  const limitPage = mockSyncPage(({ categoryId }) => ({
    status: 200,
    headers: {},
    text: categoryId === '261285'
      ? listApiText(11, ['93000001', '93000002'])
      : listApiText(11, ['35020603']),
  }));
  try {
    const limitResult = await runSync(baseSyncOptions(limitDir, limitDb, { limit: 1 }), {
      context: {},
      page: limitPage,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(limitResult.status, 'interrupted');
    assert.equal(limitResult.completeness.complete, false);
    assert.ok(limitResult.completeness.reasons.some((reason) => /limit/.test(reason)));
  } finally {
    fs.rmSync(limitDir, { recursive: true, force: true });
  }
});

test('旧断点从最后成功保存的非空页继续，且不信任旧 completed', async () => {
  const { directory, dbPath } = tempDb();
  const firstPage = mockSyncPage(({ categoryId }) => ({
    status: 200,
    headers: {},
    text: categoryId === '261285'
      ? listApiText(10012, ['94000001'])
      : listApiText(10012, ['35020603']),
  }));
  try {
    const first = await runSync(baseSyncOptions(directory, dbPath, {
      maxPages: 1,
      maxPagesProvided: true,
    }), {
      context: {},
      page: firstPage,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(first.status, 'interrupted');
    const seed = new QuestionSyncStore(dbPath, { dataDir: directory });
    try {
      seed.db.prepare(`
        UPDATE sync_run_catalog_progress
        SET status = 'completed', expected_pages = 1, expected_total = 10012
        WHERE run_id = ?
      `).run(first.runId);
      assert.equal(seed.getRunCheckpoint(first.runId, seed.db.prepare(
        'SELECT scope_key FROM sync_run_checkpoints WHERE run_id = ?',
      ).get(first.runId).scope_key), 1);
    } finally {
      seed.close();
    }

    const catalogPages = [];
    const resumePage = mockSyncPage(({ curPage, categoryId }) => {
      if (categoryId !== '261285') {
        return { status: 200, headers: {}, text: listApiText(10013, ['35020603']) };
      }
      catalogPages.push(curPage);
      if (curPage === 2) return { status: 200, headers: {}, text: listApiText(10013, ['94000002']) };
      if (curPage >= 3) return { status: 200, headers: {}, text: listApiText(10013, []) };
      return { status: 200, headers: {}, text: listApiText(10013, ['94000001']) };
    });
    const second = await runSync(baseSyncOptions(directory, dbPath, { resume: true }), {
      context: {},
      page: resumePage,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(second.status, 'success');
    assert.equal(Math.min(...catalogPages), 2);
    assert.ok(!catalogPages.includes(1));
    assert.equal(second.completeness.counts.questionCount, 2);
    const replay = new QuestionSyncStore(dbPath, { dataDir: directory });
    try {
      const progress = replay.getRunCatalogProgress(second.runId, '260617', '261285');
      assert.equal(progress.status, 'completed');
      assert.equal(progress.lastCompletedPage, 2);
      assert.equal(progress.expectedTotal, 10013);
    } finally {
      replay.close();
    }
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('运行中目录 expectedTotal 跟随上游 total，完成后使用唯一题数', async () => {
  const { directory, dbPath } = tempDb();
  const store = new QuestionSyncStore(dbPath, { dataDir: directory });
  try {
    const runId = store.beginRun({ textbookId: '260617', bankId: 2, bankPath: 'czsx' });
    store.updateRunScope(runId, {
      textbookId: '260617',
      textbookExpectedTotal: 10012,
      summaryStrategy: 'textbook_root_probe',
    });
    const nodes = [{
      externalId: '261285', name: '第一章', level: 1, type: 'chapter',
      ancestorIds: ['261285'], categoryId: '261285', catelogTokpointId: '0',
    }];
    const first = parseQuestionListPayload({ code: '0', data: { total: 1, html: listHtml('95000001') } }).questions[0];
    const second = parseQuestionListPayload({ code: '0', data: { total: 1, html: listHtml('95000002') } }).questions[0];
    store.saveCatalogTree(runId, '260617', nodes);
    const catalog = { ...nodes[0], chapterExternalId: '261285' };
    store.savePage({
      runId, textbookExternalId: '260617', catalog, nodes, pageNumber: 1,
      expectedTotal: 10012, expectedPages: 1002, questions: [first], queryFingerprint: 'live-total',
    });
    store.savePage({
      runId, textbookExternalId: '260617', catalog, nodes, pageNumber: 2,
      expectedTotal: 10013, expectedPages: 1002, questions: [second], queryFingerprint: 'live-total',
    });
    store.close();
    const running = readLiveRunProgress(dbPath, runId, { textbookExternalId: '260617' });
    assert.equal(running.available, true);
    assert.equal(running.tree[0].expectedTotal, 10013);
    assert.equal(running.tree[0].collectedCount, 2);
    assert.equal(running.collectedQuestionCount, 2);
    assert.equal(running.totalQuestionCount, 10012);
    assert.ok(running.progressPercent == null || running.progressPercent < 100);

    const finisher = new QuestionSyncStore(dbPath, { dataDir: directory });
    try {
      finisher.completeCatalog({
        runId,
        textbookExternalId: '260617',
        catalog,
        expectedTotal: 10013,
        expectedPages: 1002,
        queryFingerprint: 'live-total',
      });
      const completeness = finisher.validateRunCompleteness(runId, {
        textbookId: '260617',
      }, nodes, {});
      assert.equal(completeness.complete, true);
      finisher.finishRun(runId, 'success', {}, null, { ...completeness, scope: { textbookId: '260617' } });
    } finally {
      finisher.close();
    }
    const done = readLiveRunProgress(dbPath, runId, { textbookExternalId: '260617' });
    assert.equal(done.collectedQuestionCount, 2);
    assert.equal(done.uniqueQuestionCount, 2);
    assert.equal(done.progressPercent, 100);
    assert.equal(done.scanComplete, true);
    assert.equal(done.tree[0].latestSourceTotal, 10013);
    assert.equal(done.tree[0].uniqueQuestionCount, 2);
    assert.equal(done.tree[0].collectedCount, 2);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('total 缺失、非法或与题目矛盾时只忽略展示值，不失败', () => {
  const missing = parseQuestionListPayload({ code: '0', data: { html: LIST_HTML } });
  assert.equal(missing.questions[0].externalId, '35020603');
  assert.equal(missing.total, null);

  const invalid = parseQuestionListPayload({ code: '0', data: { total: 'abc', html: LIST_HTML } });
  assert.equal(invalid.questions.length, 1);
  assert.equal(invalid.total, null);

  const contradictory = parseQuestionListPayload({ code: '0', data: { total: 0, html: LIST_HTML } });
  assert.equal(contradictory.questions.length, 1);
  assert.equal(contradictory.total, null);

  const emptyKnown = parseQuestionListPayload({ code: '0', data: { total: 0, html: '' } });
  assert.deepEqual(emptyKnown.questionIds, []);
  assert.equal(emptyKnown.total, 0);

  assert.equal(parseQuestionListTotalPayload({ code: '0', data: {} }).total, null);
  const signature = validatePageResult({
    total: null,
    questions: [{ externalId: '1' }],
    questionIds: ['1'],
  }, 1, null, new Set());
  assert.equal(typeof signature, 'string');
});

test('教材根目录 total 探针失败时降级为警告并继续采集', async () => {
  const { directory, dbPath } = tempDb();
  const catalogPages = [];
  const page = mockSyncPage(({ curPage, categoryId }) => {
    if (categoryId !== '261285') {
      return { status: 400, headers: {}, text: 'probe failed' };
    }
    catalogPages.push(curPage);
    if (curPage === 1) return { status: 200, headers: {}, text: JSON.stringify({ code: '0', data: { html: listHtml('96000001') } }) };
    return { status: 200, headers: {}, text: JSON.stringify({ code: '0', data: { html: '' } }) };
  });
  try {
    const result = await runSync(baseSyncOptions(directory, dbPath), {
      context: {},
      page,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(result.status, 'success');
    assert.ok(catalogPages.includes(1) && catalogPages.includes(2));
    assert.equal(result.completeness.counts.questionCount, 1);
    const replay = new QuestionSyncStore(dbPath, { dataDir: directory });
    try {
      const scope = JSON.parse(replay.getRun(result.runId).scope_json);
      assert.equal(scope.textbookExpectedTotal, null);
      assert.equal(scope.summaryStrategy, 'textbook_root_probe_unavailable');
    } finally {
      replay.close();
    }
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('分页 total=0 但页面有题时继续抓取，空页仍结束目录', async () => {
  const { directory, dbPath } = tempDb();
  const catalogPages = [];
  const page = mockSyncPage(({ curPage, categoryId }) => {
    if (categoryId !== '261285') {
      return { status: 200, headers: {}, text: listApiText(0, []) };
    }
    catalogPages.push(curPage);
    if (curPage === 1) return { status: 200, headers: {}, text: listApiText(0, ['97000001']) };
    return { status: 200, headers: {}, text: listApiText(0, []) };
  });
  try {
    const result = await runSync(baseSyncOptions(directory, dbPath), {
      context: {},
      page,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(result.status, 'success');
    assert.ok(catalogPages.includes(1) && catalogPages.includes(2));
    assert.equal(result.completeness.counts.questionCount, 1);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('列表默认 8 路并发请求，空页仍结束目录', async () => {
  const { directory, dbPath } = tempDb();
  const catalogPages = [];
  const page = mockSyncPage(({ curPage, categoryId }) => {
    if (categoryId !== '261285') {
      return { status: 200, headers: {}, text: listApiText(40, ['35020603']) };
    }
    catalogPages.push(curPage);
    if (curPage <= 2) {
      return { status: 200, headers: {}, text: listApiText(40, [`9800000${curPage}`]) };
    }
    return { status: 200, headers: {}, text: listApiText(40, []) };
  });
  try {
    const result = await runSync(baseSyncOptions(directory, dbPath), {
      context: {},
      page,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(result.status, 'success');
    assert.deepEqual([...new Set(catalogPages)].sort((a, b) => a - b), [1, 2, 3, 4, 5, 6, 7, 8]);
    assert.equal(result.completeness.counts.questionCount, 2);
    const replay = new QuestionSyncStore(dbPath, { dataDir: directory });
    try {
      assert.equal(replay.getRunCatalogProgress(result.runId, '260617', '261285').lastCompletedPage, 2);
    } finally {
      replay.close();
    }
    const live = readLiveRunProgress(dbPath, result.runId, { textbookExternalId: '260617' });
    assert.equal(live.fetchWindows.length, 1);
    assert.equal(live.fetchWindows[0].catalogExternalId, '261285');
    assert.equal(live.fetchWindows[0].slots.length, 8);
    assert.equal(live.fetchWindows[0].slots[0].pageNumber, 1);
    assert.equal(live.fetchWindows[0].slots[0].status, 'saved');
    assert.match(String(live.fetchWindows[0].slots[0].line), /catalog=261285 page=1 questions=1 total=40/);
    assert.equal(live.fetchWindows[0].slots[2].status, 'empty');
    assert.equal(live.tree[0].current, true);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('风控页会保存此前成功页，并打开全新无痕会话继续剩余页', async () => {
  const { directory, dbPath } = tempDb();
  let persistentLaunches = 0;
  let freshLaunches = 0;
  const makePage = (blocked) => mockSyncPage(({ curPage, categoryId }) => {
    if (categoryId !== '261285') {
      return { status: 200, headers: {}, text: listApiText(20, ['35020603']) };
    }
    if (blocked && curPage >= 2) {
      return { status: 403, headers: {}, text: '<html>验证码</html>' };
    }
    if (curPage === 1) return { status: 200, headers: {}, text: listApiText(20, ['99000001']) };
    if (curPage === 2) return { status: 200, headers: {}, text: listApiText(20, ['99000002']) };
    return { status: 200, headers: {}, text: listApiText(20, []) };
  });
  const firstPage = makePage(true);
  const secondPage = makePage(false);
  const makeContext = (current) => ({
    pages: () => [current],
    newPage: async () => current,
    setDefaultTimeout() {},
    setDefaultNavigationTimeout() {},
    close: async () => {},
  });
  const playwright = {
    chromium: {
      launchPersistentContext: async () => {
        persistentLaunches += 1;
        return makeContext(firstPage);
      },
      launch: async () => {
        freshLaunches += 1;
        return {
          newContext: async () => makeContext(secondPage),
          close: async () => {},
        };
      },
    },
  };
  try {
    const result = await runSync(baseSyncOptions(directory, dbPath, {
      profileDir: path.join(directory, 'main-profile'),
    }), {
      playwright,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(result.status, 'success');
    assert.equal(persistentLaunches, 1);
    assert.equal(freshLaunches, 1);
    assert.equal(result.completeness.counts.questionCount, 2);
    assert.equal(isCookieSwitchError(new VerificationRequiredError('x')), true);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('安全页数上限只标记知识点异常并继续，不作为正常完成', async () => {
  const { directory, dbPath } = tempDb();
  const catalogPages = [];
  const page = mockSyncPage(({ curPage, categoryId }) => {
    if (categoryId !== '261285') {
      return { status: 200, headers: {}, text: listApiText(40, ['35020603']) };
    }
    catalogPages.push(curPage);
    return { status: 200, headers: {}, text: listApiText(40, [String(96000000 + curPage)]) };
  });
  try {
    const result = await runSync(baseSyncOptions(directory, dbPath, {
      maxPages: 1000,
      maxPagesProvided: false,
      safetyPageLimit: 3,
      concurrency: 8,
    }), {
      context: {},
      page,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(result.status, 'success');
    assert.equal(Math.max(...catalogPages), 3);
    assert.ok(!catalogPages.includes(4));
    assert.equal(result.completeness.scanComplete, true);
    assert.equal(result.completeness.dataComplete, false);
    assert.equal(result.completeness.snapshotComplete, false);
    const replay = new QuestionSyncStore(dbPath, { dataDir: directory });
    try {
      const progress = replay.getRunCatalogProgress(result.runId, '260617', '261285');
      assert.equal(progress.status, 'stalled');
      assert.equal(progress.stallReason, 'pagination_safety_limit');
      assert.equal(progress.scanComplete, true);
      assert.equal(progress.dataComplete, false);
    } finally {
      replay.close();
    }
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('并发窗口中间页失败时仍保存后续成功页', async () => {
  const { directory, dbPath } = tempDb();
  const catalogPages = [];
  const page = mockSyncPage(({ curPage, categoryId }) => {
    if (categoryId !== '261285') {
      return { status: 200, headers: {}, text: listApiText(30, ['35020603']) };
    }
    catalogPages.push(curPage);
    if (curPage === 2) return { status: 500, headers: {}, text: 'busy' };
    if (curPage === 1) return { status: 200, headers: {}, text: listApiText(30, ['98100001']) };
    if (curPage === 3) return { status: 200, headers: {}, text: listApiText(30, ['98100003']) };
    return { status: 200, headers: {}, text: listApiText(30, []) };
  });
  try {
    const result = await runSync(baseSyncOptions(directory, dbPath, { concurrency: 8 }), {
      context: {},
      page,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(result.status, 'success');
    assert.equal(result.completeness.scanComplete, true);
    assert.equal(result.completeness.dataComplete, false);
    assert.equal(result.completeness.snapshotComplete, false);
    assert.ok(catalogPages.includes(1) && catalogPages.includes(3));
    const replay = new QuestionSyncStore(dbPath, { dataDir: directory });
    try {
      const ids = replay.db.prepare(
        'SELECT question_external_id AS id FROM sync_run_question_items ORDER BY question_external_id',
      ).all().map((row) => row.id);
      assert.deepEqual(ids, ['98100001', '98100003']);
      const pages = replay.db.prepare(
        'SELECT page_number, result_type FROM sync_run_catalog_pages ORDER BY page_number',
      ).all();
      assert.equal(pages.find((row) => Number(row.page_number) === 2).result_type, PAGE_RESULT.REQUEST_FAILED);
      assert.equal(pages.find((row) => Number(row.page_number) === 3).result_type, PAGE_RESULT.SUCCESS);
      const progress = replay.getRunCatalogProgress(result.runId, '260617', '261285');
      assert.equal(progress.lastCompletedPage, 1);
      assert.ok(progress.highestAttemptedPage >= 3);
    } finally {
      replay.close();
    }
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('目标范围内空页且后续仍有题时继续采集并记为数据异常', async () => {
  const { directory, dbPath } = tempDb();
  const page = mockSyncPage(({ curPage, categoryId }) => {
    if (categoryId !== '261285') {
      return { status: 200, headers: {}, text: listApiText(40, ['35020603']) };
    }
    if (curPage === 1) return { status: 200, headers: {}, text: listApiText(40, ['98200001']) };
    if (curPage === 2) return { status: 200, headers: {}, text: listApiText(40, []) };
    if (curPage === 3) return { status: 200, headers: {}, text: listApiText(40, ['98200003']) };
    return { status: 200, headers: {}, text: listApiText(40, []) };
  });
  try {
    const result = await runSync(baseSyncOptions(directory, dbPath), {
      context: {},
      page,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(result.status, 'success');
    assert.equal(result.completeness.scanComplete, true);
    assert.equal(result.completeness.dataComplete, false);
    const replay = new QuestionSyncStore(dbPath, { dataDir: directory });
    try {
      const ids = replay.db.prepare(
        'SELECT question_external_id AS id FROM sync_run_question_items ORDER BY question_external_id',
      ).all().map((row) => row.id);
      assert.deepEqual(ids, ['98200001', '98200003']);
      const empty = replay.db.prepare(
        "SELECT page_number FROM sync_run_catalog_pages WHERE result_type = 'empty_page'",
      ).all();
      assert.ok(empty.some((row) => Number(row.page_number) === 2));
    } finally {
      replay.close();
    }
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('一个知识点卡死后继续采集下一个知识点', async () => {
  const { directory, dbPath } = tempDb();
  const requested = [];
  const tree = {
    id: '260617',
    title: '九年级上册',
    children: [
      { id: '261285', title: '第一章', children: [] },
      { id: '261286', title: '第二章', children: [] },
    ],
  };
  const page = mockSyncPage(({ curPage, categoryId }) => {
    requested.push(`${categoryId}:${curPage}`);
    if (categoryId === '261285') {
      return { status: 200, headers: {}, text: listApiText(30, [`${97000000 + curPage}`]) };
    }
    if (categoryId === '261286') {
      if (curPage === 1) return { status: 200, headers: {}, text: listApiText(10, ['98300001']) };
      return { status: 200, headers: {}, text: listApiText(10, []) };
    }
    return { status: 200, headers: {}, text: listApiText(10, ['35020603']) };
  });
  try {
    const result = await runSync(baseSyncOptions(directory, dbPath, {
      safetyPageLimit: 3,
      concurrency: 1,
    }), {
      context: {},
      page,
      catalogTree: tree,
    });
    assert.equal(result.status, 'success');
    assert.ok(requested.some((item) => item.startsWith('261286:')));
    const replay = new QuestionSyncStore(dbPath, { dataDir: directory });
    try {
      const first = replay.getRunCatalogProgress(result.runId, '260617', '261285');
      const second = replay.getRunCatalogProgress(result.runId, '260617', '261286');
      assert.equal(first.status, 'stalled');
      assert.equal(second.status, 'completed');
      assert.equal(second.scanComplete, true);
      assert.equal(replay.db.prepare(
        "SELECT COUNT(*) AS n FROM sync_run_question_items WHERE question_external_id = '98300001'",
      ).get().n, 1);
    } finally {
      replay.close();
    }
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('图片下载失败时仍保存题目，并标记数据不完整', async () => {
  const { directory, dbPath } = tempDb();
  const page = mockSyncPage(({ curPage, categoryId }) => {
    if (categoryId !== '261285') {
      return { status: 200, headers: {}, text: listApiText(10, ['35020603']) };
    }
    if (curPage === 1) return { status: 200, headers: {}, text: listApiText(10, ['98400001']) };
    return { status: 200, headers: {}, text: listApiText(10, []) };
  });
  const context = {
    pages: () => [page],
    newPage: async () => page,
    request: {
      get: async () => {
        throw Object.assign(new Error('素材 503'), { code: 'asset_http_503' });
      },
    },
  };
  try {
    const result = await runSync(baseSyncOptions(directory, dbPath, { downloadAssets: true }), {
      context,
      page,
      catalogTree: SAMPLE_TREE,
    });
    assert.equal(result.status, 'success');
    assert.equal(result.completeness.scanComplete, true);
    assert.equal(result.completeness.dataComplete, false);
    assert.equal(result.completeness.snapshotComplete, false);
    const replay = new QuestionSyncStore(dbPath, { dataDir: directory });
    try {
      assert.equal(replay.db.prepare('SELECT COUNT(*) AS n FROM sync_run_question_items').get().n, 1);
      const asset = replay.db.prepare('SELECT source_url, content_sha256 FROM sync_run_question_assets').get();
      assert.ok(asset?.source_url);
      assert.equal(asset.content_sha256, null);
      const progress = replay.getRunCatalogProgress(result.runId, '260617', '261285');
      assert.ok(progress.assetErrorCount > 0);
    } finally {
      replay.close();
    }
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

