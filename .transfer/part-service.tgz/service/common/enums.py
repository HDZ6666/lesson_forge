from enum import Enum


class HttpMethod(str, Enum):
    """
    HTTP请求方法枚举

    GET: 获取资源
    POST: 创建资源
    PUT: 整体更新资源
    DELETE: 删除资源
    PATCH: 局部更新资源
    HEAD: 获取响应头
    OPTIONS: 获取允许的方法信息
    TRACE: 回显诊断请求
    CONNECT: 建立隧道连接
    """

    GET = 'GET'
    POST = 'POST'
    PUT = 'PUT'
    DELETE = 'DELETE'
    PATCH = 'PATCH'
    HEAD = 'HEAD'
    OPTIONS = 'OPTIONS'
    TRACE = 'TRACE'
    CONNECT = 'CONNECT'


class BusinessType(Enum):
    """
    业务操作类型

    OTHER: 其它
    INSERT: 新增
    UPDATE: 修改
    DELETE: 删除
    GRANT: 授权
    EXPORT: 导出
    IMPORT: 导入
    FORCE: 强退
    GENCODE: 生成代码
    CLEAN: 清空数据
    """

    OTHER = 0
    INSERT = 1
    UPDATE = 2
    DELETE = 3
    GRANT = 4
    EXPORT = 5
    IMPORT = 6
    FORCE = 7
    GENCODE = 8
    CLEAN = 9


class PasswordCharacterType(Enum):
    """
    密码字符范围类型
    """

    def __init__(self, code: str, pattern: str, message: str) -> None:
        self.code = code
        self.pattern = pattern
        self.message = message

    @classmethod
    def from_code(cls, code: str | bytes | None) -> 'PasswordCharacterType':
        """
        根据配置值获取密码字符范围类型

        :param code: 密码字符范围配置值
        :return: 密码字符范围类型
        """
        if isinstance(code, bytes):
            code = code.decode()

        return next((item for item in cls if item.code == code), cls.DEFAULT)

    DEFAULT = ('0', r"""^[^<>"'|\\]+$""", '密码不能包含非法字符：< > " \' \\ |')
    NUMBER = ('1', r'^[0-9]+$', '密码只能为数字（0-9）')
    LETTER = ('2', r'^[a-zA-Z]+$', '密码只能为英文字母（a-z、A-Z）')
    LETTER_NUMBER = ('3', r'^(?=.*[a-zA-Z])(?=.*[0-9])[a-zA-Z0-9]+$', '密码必须同时包含字母和数字')
    LETTER_NUMBER_SPECIAL = (
        '4',
        r'^(?=.*[A-Za-z])(?=.*\d)(?=.*[~!@#$%^&*()\-=_+])[A-Za-z\d~!@#$%^&*()\-=_+]+$',
        '密码必须同时包含字母、数字和特殊字符（~!@#$%^&*()-=_+）',
    )


class RedisInitKeyConfig(Enum):
    """
    系统内置Redis键名
    """

    @property
    def key(self) -> str | None:
        return self.value.get('key')

    @property
    def remark(self) -> str | None:
        return self.value.get('remark')

    ACCESS_TOKEN = {'key': 'access_token', 'remark': '登录令牌信息'}
    SYS_DICT = {'key': 'sys_dict', 'remark': '数据字典'}
    SYS_CONFIG = {'key': 'sys_config', 'remark': '配置信息'}
    API_CACHE = {'key': 'api_cache', 'remark': '接口响应缓存'}
    API_RATE_LIMIT = {'key': 'api_rate_limit', 'remark': '接口限流'}
    CAPTCHA_CODES = {'key': 'captcha_codes', 'remark': '图片验证码'}
    ACCOUNT_LOCK = {'key': 'account_lock', 'remark': '用户锁定'}
    PASSWORD_ERROR_COUNT = {'key': 'password_error_count', 'remark': '密码错误次数'}
    SMS_CODE = {'key': 'sms_code', 'remark': '短信验证码'}
