from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel
from pydantic_validation_decorator import NotBlank, Size


class ConfigModel(BaseModel):
    """
    参数配置表对应pydantic模型
    """

    model_config = ConfigDict(alias_generator=to_camel, from_attributes=True)

    config_id: int | None = Field(default=None, description='参数主键')
    config_name: str | None = Field(default=None, description='参数名称')
    config_key: str | None = Field(default=None, description='参数键名')
    config_value: str | None = Field(default=None, description='参数键值')
    config_type: Literal['Y', 'N'] | None = Field(default=None, description='系统内置（Y是 N否）')
    create_by: str | None = Field(default=None, description='创建者')
    create_time: datetime | None = Field(default=None, description='创建时间')
    update_by: str | None = Field(default=None, description='更新者')
    update_time: datetime | None = Field(default=None, description='更新时间')
    remark: str | None = Field(default=None, description='备注')

    @NotBlank(field_name='config_key', message='参数名称不能为空')
    @Size(field_name='config_key', min_length=0, max_length=100, message='参数名称长度不能超过100个字符')
    def get_config_key(self) -> str | None:
        return self.config_key

    @NotBlank(field_name='config_name', message='参数键名不能为空')
    @Size(field_name='config_name', min_length=0, max_length=100, message='参数键名长度不能超过100个字符')
    def get_config_name(self) -> str | None:
        return self.config_name

    @NotBlank(field_name='config_value', message='参数键值不能为空')
    @Size(field_name='config_value', min_length=0, max_length=500, message='参数键值长度不能超过500个字符')
    def get_config_value(self) -> str | None:
        return self.config_value

    def validate_fields(self) -> None:
        self.get_config_key()
        self.get_config_name()
        self.get_config_value()


class ConfigQueryModel(ConfigModel):
    """
    参数配置管理不分页查询模型
    """

    begin_time: str | None = Field(default=None, description='开始时间')
    end_time: str | None = Field(default=None, description='结束时间')


class ConfigPageQueryModel(ConfigQueryModel):
    """
    参数配置管理分页查询模型
    """

    page_num: int = Field(default=1, description='当前页码')
    page_size: int = Field(default=10, description='每页记录数')


class DeleteConfigModel(BaseModel):
    """
    删除参数配置模型
    """

    model_config = ConfigDict(alias_generator=to_camel)

    config_ids: str = Field(description='需要删除的参数主键')
